import App from "../components/App";

export default function Index() {
  return <App />;
}
